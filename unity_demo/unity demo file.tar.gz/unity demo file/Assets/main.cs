﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


// class for fruit
public class Fruit
{
	string fruitName;
	string fruitColor;
	int fruitWeight;
	
	
	//constructor
	public Fruit(string fruit_name ,string fruit_color ,int min_weight ,int max_weight )
	{
		 fruitName = fruit_name;
		 fruitColor = fruit_color;
		 fruitWeight = GetRandomNumber(min_weight,max_weight);
	}
	
	public int GetRandomNumber(int min_weight ,int max_weight)
	{
	    int x;
		x= Random.Range(min_weight,max_weight);
		return x;
	}
	
	public string GetFruitName()
	{
		return fruitName;
	}
	
	public string GetFruitColor()
	{
		return fruitColor;
	}
	public int GetFruitWeight()
	{
		return fruitWeight;
	}
	public void seta(string a ,string b, int c)
	{
		fruitName =a;
		fruitColor =b;
		fruitWeight =c;
	}

	


	
}

// class basket
public class Basket
{
	Fruit[] fruitBasket;
	int fruitbasketSize;
	int newfruitsSize;
	
	
	public Basket(int fruit_basket_size)
	{
		fruitbasketSize = fruit_basket_size;
		fruitBasket = new Fruit[fruit_basket_size];
		newfruitsSize = 0;
	}
	
	public Fruit[] GetFruitBasket()
	{
		return fruitBasket;
	}
	
	public int GetFruitBasketSize()
	{
		return fruitbasketSize;
	}
	
	public int GetNewFruitsSize()
	{
		return  newfruitsSize ;
	}
	
	public void AddFruit(string fruit_name ,string fruit_color ,int min_weight ,int max_weight ,int i)
	{
		GameObject anyfruit;
		GameObject fruitx;
		Fruit fruit1 = new Fruit(fruit_name ,fruit_color ,min_weight ,max_weight);
		fruitBasket[i] = fruit1;
		anyfruit = GameObject.FindWithTag(fruit_name);
		//anyfruit.transform.position = new Vector3(100,5 ,105);
		fruitx = GameObject.Instantiate(anyfruit);
		fruitx.transform.position = new Vector3(Random.Range(96 ,104),Random.Range(5 ,100) ,Random.Range(101 ,109));
		if (fruit_name == "Apple")
		{
			fruitx.tag = "Applec";
		}
		else if (fruit_name == "Lemon")
		{
			fruitx.tag ="Lemonc";
		}
		else
		{
			fruitx.tag ="Watermelonc";
		}
	}
	
	public void MinusFruit(string fruit_type , int fruit_weight)
	{
		//int a =0;
	
		for(int i=0;i<12;i++)
		{
			if(fruitBasket[i].GetFruitName() == fruit_type && fruitBasket[i].GetFruitWeight() < fruit_weight)
			{
				 
				 
				 if(fruitBasket[i].GetFruitName() == "Apple")
				 {
					 fruitBasket[i].seta("discard apple","discard",0);
					
					 
					 
				 }
				 else if (fruitBasket[i].GetFruitName() == "Lemon")
				 {
					 fruitBasket[i].seta("discard lemon","discard",0);
					  
				 }
				 else
				 {
					 fruitBasket[i].seta("discard watermelon","discard",0);
					 
				 }
				 
				 //fruitBasket[a] = fruitBasket[i];
				 //a++;
			}
			else
			{
				
			}
		
		}
		
	
		//GameObject []  newfruits;
		//newfruits=GameObject.FindGameObjectsWithTag(fruit_type+"c");
		//GameObject.Destroy(newfruits[]);
		
		/*
		Fruit [] newfruitBasket = new Fruit[fruitbasketSize];
	   
		int a =0;
		
		for (int i = 0;i<fruitbasketSize;i++)
		{
			if(fruitBasket[i].GetFruitName()==fruit_type && fruitBasket[i].GetFruitWeight() < fruit_weight)
			{
				
				fruitbasketSize--;
			    
			}
			else
			{
				newfruitBasket[a]=fruitBasket[i+1];
				fruitBasket[a] = newfruitBasket[a];
				a++;
			}
		}
		
         
		*/
		
		
	}
	
	
	public Fruit[] GetFruits(string fruit_type)
	{
	    
		for(int i =0;i<12;i++)
		{
			if(fruitBasket[i].GetFruitName() == fruit_type)
			{
				newfruitsSize++;
			}
		}
		
		Fruit[] newFruits = new Fruit[newfruitsSize];
		int a=0;
		
		
		for (int i =0;i<12;i++)
	    {
			if(fruitBasket[i].GetFruitName()== fruit_type)
			{
				newFruits[a] = fruitBasket[i];
				a++;
			}
		}
		
		return newFruits;
		
	}
	
	
}

// class game manager
public class GameManager
{
	Basket basket1;
	int basketsize;
	
	public GameManager()
	{
		basket1 = new Basket(12);
		FillBasket();
		Show();
		RefillBasket();
		DiscardFruits();
	   
		
	}
	
	public void FillBasket()
	{
		for (int i=0;i<12;i++)
		{
			if (i<3)
			{
			  basket1.AddFruit("Apple","Red",300,800,i);
			}
			else if(i>2 && i <9)
			{
				basket1.AddFruit("Lemon","Yellow",100,600,i);
			}
			else
			{
				basket1.AddFruit("Watermelon","Green",300,1000,i);
			}
		}
		
	}
	
    public void Show()
	{
		basketsize = basket1.GetFruitBasketSize();
		//Debug.Log(basketsize);
		Fruit [] newfruitbasket = new Fruit[basketsize];
        newfruitbasket = basket1.GetFruitBasket();
	    
		GameObject text1;
		text1 = GameObject.FindWithTag("text");
		
		Text newtext;
		newtext=text1.GetComponent<Text>();
		newtext.text = "";
        for (int i=0;i<12;i++)
        {
		    //int a = newfruitbasket[i].GetFruitWeight();	
		    newtext.text = newtext.text + newfruitbasket[i].GetFruitName() + "  " + newfruitbasket[i].GetFruitColor() + "  " + newfruitbasket[i].GetFruitWeight()  +"\n";
			//Debug.Log("a"+i+a);
			
		}			
	}
	
	
	public void Refill()
	{
		GameObject [] fruit;
		fruit = GameObject.FindGameObjectsWithTag("Applec");
		for(int i=0 ; i<fruit.Length;i++)
		{
		GameObject.Destroy(fruit[i]);
		}
		fruit = GameObject.FindGameObjectsWithTag("Lemonc");
		for(int i=0 ; i<fruit.Length;i++)
		{
		GameObject.Destroy(fruit[i]);
		}
		fruit = GameObject.FindGameObjectsWithTag("Watermelonc");
		for(int i=0 ; i<fruit.Length;i++)
		{
		GameObject.Destroy(fruit[i]);
		}
		
		
		
		GameManager game1 = new GameManager();
	}
	
	
	public void RefillBasket()
	{
		GameObject refill;
		refill = GameObject.FindWithTag("refill");
		
		Button b1;
		b1 = refill.GetComponent<Button>();
		b1.onClick.AddListener(Refill);
		
		
		
	}
	
	public void Discard()
	{
		Debug.Log("the time of time");
		GameObject applef;
		GameObject lemonf;
		GameObject watermelonf;
		
		applef = GameObject.FindWithTag("numberapple");
		lemonf = GameObject.FindWithTag("numberlemon");
		watermelonf = GameObject.FindWithTag("numberwatermelon");
	
		InputField a1 = applef.GetComponent<InputField> ();
        InputField l1 = lemonf.GetComponent<InputField>	();
		InputField w1 = watermelonf.GetComponent<InputField> ();
		
		
		
        		
		string a = a1.text;
		string b = l1.text;
		string c = w1.text;
		
		int x = System.Convert.ToInt32(a);
		int y = System.Convert.ToInt32(b);
		int z = System.Convert.ToInt32(c);
		
		basket1.MinusFruit("Apple",x);
		basket1.MinusFruit("Lemon",y);
		basket1.MinusFruit("Watermelon",z);
		// to discard lemon
		
		
	   DestroyFruit("Apple");
	   DestroyFruit("Lemon");
	   DestroyFruit("Watermelon");	
	   Show();
		
	
		
	}
	
	public void DestroyFruit(string fruit_name)
	{
		/*
		GameObject [] newfruits;
		newfruits=GameObject.FindGameObjectsWithTag(fruit_name+"c");
		basket1.GetFruits(fruit_name);
		for(int i =basket1.GetNewFruitsSize();i<newfruits.Length;i++)
		{
		    Debug.Log(basket1.GetNewFruitsSize());
			GameObject.Destroy(newfruits[i]);
		}
		*/
		
	
		
		
	}
	
	
	public void DiscardFruits()
	{
		GameObject discard;
		discard = GameObject.FindWithTag("discard");
		
		Button b1;
		b1 = discard.GetComponent<Button>();
		b1.onClick.AddListener(Discard);
	}
	
	
	
}



public class main : MonoBehaviour {

	// Use this for initialization
	void Start () {
		GameManager game1 = new GameManager();
		
		}


	// Update is called once per frame
	void Update () {
		
	}
}
